require 'env_config/install'
require 'env_config/shell_customizations'
require 'env_config/commands/ln_to_bin'

module EnvConfig
  module App
    extend self

    def run(options)
      EnvConfig.const_get(options.subcommand.split('-').map!{ |part| part.capitalize }.join).run options
    end
  end
end

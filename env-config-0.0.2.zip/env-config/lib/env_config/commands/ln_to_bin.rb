%w{ env_config fileutils ostruct }.each { |lib| require lib }

include EnvConfig

module EnvConfig
  module LnToBin
    extend self

    LnToBinError = Class.new Exception

    TYPES = { :py => 'python', :rb => 'ruby', :sh => 'shell' }

    def file_properties(filename)
      file           = OpenStruct.new
      file.name      = File.basename(filename)
      file.extension = File.extname(filename)
      file.wo_ext    = File.basename(file.name, file.extension)
      if file.extension.empty?
        message = ["The file: '#{file.name}' does not have an extension.", "Cannot tell the type of file."].join("\n")
        raise LnToBinError, message
      end

      if TYPES.has_key? file.extension[1..-1].intern
        file.type = TYPES[file.extension[1..-1].intern]
      else
        raise LnToBinError, "The file extension: '#{file.extension}' is not a valid type."
      end
      file
    end

    def ln_to_bin(paths)
      if File.exist?(paths.bin)
        #raise LnToBinError, "The symlink for: '#{paths.bin}' already exists in bin"
        puts "The symlink for: '#{paths.bin}' already exists in bin"
        exit 1
      else
        FileUtils.ln_s(paths.search.first, paths.bin)
      end
    end

    def run options
      file  = file_properties(options.filename)
      paths = paths(file)
      ln_to_bin(paths)
    end

    def paths(file)
      paths     = OpenStruct.new
      paths.bin = File.join(dev_path, 'bin', file.wo_ext.gsub('_', '-'))
      priv_path = File.join(dev_path, 'private', file.type, file.name)
      pub_path  = File.join(dev_path, 'public', file.type, file.name)
      paths.search = []
      paths.search << priv_path if File.exist? priv_path
      paths.search << pub_path  if File.exist? pub_path
      raise LnToBinError, "Cannot find a script by that name in any of the script locations." if paths.search.empty?
      return paths
    end
  end
end

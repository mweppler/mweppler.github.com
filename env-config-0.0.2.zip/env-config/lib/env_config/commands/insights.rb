require 'digest/sha1'
require 'env_config'
require 'fileutils'
require 'env_config/install'
require 'ostruct'
require 'securerandom'
require 'env_config/shell_customizations'

include EnvConfig

module EnvConfig
  module Insights
    extend self

    user    = ENV['USER']
    home    = ENV['HOME']
    #command = $0.split('/').last
    command = ARGV.shift
    dot_dir = File.join home, ".#{command}"
    log_dir = File.join dot_dir, 'insights'
    logging_level = nil

    if File.exists? File.join(log_dir, '.insight-level')
      File.open(File.join(log_dir, '.insight-level'), 'r') do |f|
        contents = f.read
        user, logging_level = contents.split(':')
      end
    else
      logging_level = ask('Do you want to allow logging?', ['yes', 'no', 'anonymous'])
      user = SecureRandom.uuid if logging_level == 'anonymous'
      FileUtils.mkdir_p log_dir
      File.open(File.join(log_dir, '.insight-level'), 'w') { |f| f.write "#{user}:#{logging_level}" }
    end

    #puts "Logging #{user}:#{logging_level}"

    unless File.exists? File.join(log_dir, '.insight-log')
      File.open(File.join(log_dir, '.insight-log'), 'w').close
    end

    full_command = command + ' ' + ARGV.join(' ')

    #exit 0 if full_command == command + ' --version'

    version = 'no-version'
    subcommand = 'no-subcommand'

    #system('echo ' + full_command)
    system(full_command)

    log_entry = [
      "[#{user}]",
      "[#{Time.now}]",
      "[#{RUBY_PLATFORM}]",
      "[#{command}]",
      "[#{version}]",
      "[#{subcommand}]",
      "[#{ARGV.join('/')}]",
      "[#{$?.exitstatus}]"
    ].join(' ')

    log_entry = "[#{Digest::SHA1.hexdigest(log_entry)}]" << ' ' << log_entry

    File.open(File.join(log_dir, '.insight-log'), 'a') { |file| file.write "#{log_entry}\n" }

    exit 0

    if backend_exists
      entries = []
      File.open(File.join(log_dir, '.insight-log'), 'r') { |file| entries = file.readlines }
      send_entries_to_endpoint(entries)
    end

    if success
      File.truncate(File.join log_dir, '.insight-log')
    end
  end
end

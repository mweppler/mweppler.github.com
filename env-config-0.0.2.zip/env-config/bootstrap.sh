#!/usr/bin/env sh

die() {
  echo "${@}"
  exit 1
}

mkdir -p $HOME/.env_config || die "Could not create the directory ${HOME}/.env_config in your home."

cd $HOME/.env_config

git clone https://github.com/mweppler/env-config.git $HOME/.env_config/env-config

cd $HOME/.env_config/env-config || die "Could not change into the ${HOME}/.env_config/env-config"

rake install || die "Rake failed."

require 'helper'

class TestBinOptions < EnvConfig::TestCase

  def test_help_option
    actual = %x[#{EnvConfig::ENV_CONFIG_CMD} --help].chop
    expected = <<-HELP.gsub(/^[ ]{6}/, '').chop
      EnvConfig: An somewhat opinionated developer environment.

        Usage:
          env-config [SUBCOMMAND] [OPTIONS]

            SUBCOMMANDS: ln-to-bin

        Examples:
          env-config ln-to-bin --file cool_ruby_script.rb

        Options:
          -f, --file [FILE]                For use with link-to-bin.
          -?, --help                       Display this message.
              --version                    Display current version.
    HELP
    assert_equal expected, actual
  end

  def test_invalid_option
    expected = <<-OPTION.gsub(/^[ ]{6}/, '').chop
      env-config: invalid option: env-config requires a subcommand
      env-config: try 'env-config --help' for more information
    OPTION
    actual = %x[#{EnvConfig::ENV_CONFIG_CMD} --asdf].chop
    assert_equal expected, actual
  end

  def test_version_option
    actual = %x[#{EnvConfig::ENV_CONFIG_CMD} --version].chop
    assert_equal 'EnvConfig: 0.0.2', actual
  end
end

require 'minitest/autorun'
require 'minitest/pride'

if ENV['COVERAGE']
  require 'simplecov'
  SimpleCov.start
else
  require 'coveralls'
  Coveralls.wear!
end

require 'env_config'

module EnvConfig

  ROOT_PATH      = File.expand_path(File.join(File.dirname(__FILE__), '..'))
  ENV_CONFIG_CMD = File.expand_path(File.join(ROOT_PATH, 'bin', 'env-config'))

  class TestCase < Minitest::Test
    # ...
  end
end
